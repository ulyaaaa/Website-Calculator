/javascript or JS for short. The main function of JS is to make a website more interactive and more attractive. JS is a programming language whose scripts are run on the user's device browser, in contrast to other programming languages ​​whose scripts are run by the server./

function insert(num){
  document.form.hasil.value = document.form.hasil.value+num;
}

function equal(){
  const exp = document. form.hasil.value;
  if(exp){
    document.form.hasil.value = eval(exp);
  }
}

function clear(){
  document.form.hasil.value ="";
}

function back(){
  const exp = document.form.hasil.value;
  document.form.hasil.value = exp.substring(0,exp.length-1);
}
